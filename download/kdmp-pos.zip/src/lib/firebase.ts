// Firebase Configuration for KDMP Sindangjaya POS System

import { initializeApp, getApps } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyDkIIijVOo5AxqV_ArZvpgsBSYJTRfrbuc",
  authDomain: "appsheet-kdmp.firebaseapp.com",
  projectId: "appsheet-kdmp",
  storageBucket: "appsheet-kdmp.firebasestorage.app",
  messagingSenderId: "409719616331",
  appId: "1:409719616331:web:55962a81ba1cf51e3daece"
};

// Initialize Firebase only if it hasn't been initialized
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];

// Initialize Firestore
const db = getFirestore(app);

export { app, db };

// Collection names
export const COLLECTIONS = {
  MEMBERS: 'members',
  PRODUCTS: 'products',
  TRANSACTIONS: 'transactions',
  DEBTS: 'debts',
  DEBT_PAYMENTS: 'debtPayments'
} as const;
